import 'base_project_test.dart' as base;

void main() {
  base.main();
}
